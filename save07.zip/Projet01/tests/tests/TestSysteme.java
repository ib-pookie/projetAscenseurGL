package tests;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import Model.AscenseurModel;

public class TestSysteme {
	
	AscenseurModel ascenseurModel;

	@Before
	public void setUp() throws Exception {
		ascenseurModel = new AscenseurModel();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testetageActuel() {
		
		System.out.println("");
		assertEquals(0.0, ascenseurModel.getEtageActuel(), 0.0);
		
		ascenseurModel.monter();
		ascenseurModel.monter();
		
		assertEquals(1.0, ascenseurModel.getEtageActuel(), 0.0);		
	}
	
	@Test
	public void testMonterEtDecendre() {
		
		ascenseurModel.monter();
		
		assertEquals(0.5, ascenseurModel.getEtageActuel(), 0.0);
		
		ascenseurModel.monter();
		ascenseurModel.monter();
		
		assertEquals(1.5, ascenseurModel.getEtageActuel(), 0.0);
		
		ascenseurModel.descendre();
		assertEquals(1.0, ascenseurModel.getEtageActuel(), 0.0);
		
	}

}
