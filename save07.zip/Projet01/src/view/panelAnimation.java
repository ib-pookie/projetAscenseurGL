package view;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

import constante.Constantes;

/**
 * 
 * Class panelAnimation est le panel de l'animation du déplacement de la cabine
 *
 */
public class panelAnimation extends JPanel {

	private static final long serialVersionUID = 1L;

	//Position de l'ascenseur
	public Float y = new Float(100);
	
	public String etatPortAnimation = Constantes.EtatPorteFermer;
	private BufferedImage cabine;

	panelAnimation() {

		setPreferredSize(new Dimension(100, 540));
	}
	
	/**
	 * (non-Javadoc)
	 * @see javax.swing.JComponent#paintComponent(java.awt.Graphics)
	 * Cette methode est appelée lors du repaint du panel
	 */
	@Override
	public void paintComponent(Graphics g) {
		
		super.paintComponent(g);

		cabine = null;

		try {
			if (Constantes.EtatPorteFermer.equals(etatPortAnimation)) {
				cabine = ImageIO.read(getClass().getResource("/images/aRed.png"));
			} else {
				cabine = ImageIO.read(getClass().getResource("/images/aGreen.png"));
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		//Dessine la cabine dans la position Y
		g.drawImage(cabine, 20, y.intValue(), null);
	}
}
