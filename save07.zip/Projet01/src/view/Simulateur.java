package view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Observable;
import java.util.Observer;

import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;

import Model.AscenseurModel;
import Model.Demande;
import constante.Constantes;

/**
 * 
 * Class Simulateur représente la vue, implement l'interface Observer
 *
 */
public class Simulateur implements Observer {

	private JFrame jFrame;
	private AscenseurModel ascensseurModel;

	private int hEcran, lEcran;

	// Zone de texte du panel affichage text de la simulation
	private JTextField etageActuelTextFild;
	private JTextField listeEtageInterieurDemandetextField;
	private JTextField listeDemandesExterieurMonte;
	private JTextField listeDemandesExterieurDescente;
	private JTextField nextDestinationTextField;

	// Boutons interieur de la cabine
	private JButton etage5;
	private JButton etage4;
	private JButton etage3;
	private JButton etage2;
	private JButton etage1;
	private JButton etage0;
	private JButton arretUrgence;

	private JButton stopArretUrgence;

	// Boutons exterieur de la cabine
	private JButton boutonUpEtage0;
	private JButton boutonDownEtage1;
	private JButton boutonUpEtage1;
	private JButton boutonDownEtage2;
	private JButton boutonUpEtage2;
	private JButton boutonDownEtage3;
	private JButton boutonUpEtage3;
	private JButton boutonDownEtage4;
	private JButton boutonUpEtage4;
	private JButton boutonDownEtage5;

	private JLabel port;

	private JPanel panelStopArretUrgenceCommandesInterieur;
	private JPanel panelAffichage;
	private JPanel panelCommandesInterieur;
	private JPanel panelCommandeExterne;

	// Panel de l'animation de la cabine
	private panelAnimation panelAnimation;

	URL file;
	ClassLoader classLoader = new ClassLoader() {
	};

	/**
	 * Constructeur de la vue
	 */
	public Simulateur(AscenseurModel ascenseurModel) {

		this.ascensseurModel = ascenseurModel;
		drowFenetre();

	}

	/**
	 * Update pour la mise à jours des valeurs affichées suite a la notification
	 * du model apres un changement de ce dernier (observable)
	 */
	@Override
	public void update(Observable arg0, Object arg1) {

		// Mise à jours des zones text
		updateListeEtageDemanderAffichage();
		updateEtageCourantAffichage();
		updateEtageDestinationAffichage();
		updateListeEtageDemandeMonteEtDescente();

		// Ouverture ou fermeture de la porte de la cabine
		if (Constantes.EtatPorteFermer.equals(ascensseurModel.getEtatPorte())) {
			this.panelAnimation.etatPortAnimation = Constantes.EtatPorteFermer;
			fermerPort();
		}
		if (Constantes.EtatPorteOuverte.equals(ascensseurModel.getEtatPorte())) {
			this.panelAnimation.etatPortAnimation = Constantes.EtatPorteOuverte;
			ouvrirPort();
		}

		// Désactivation du bouton interne de la cabine dont la demande est
		// satisfaite
		remettreBouttonEteint();

		// Etat d'urgence
		if (ascensseurModel.isArretUrgence()) {

			ascensseurModel.setDemandeEtageDeExterieur(new ArrayList<Demande>());
			ascensseurModel.setDemandeEtageDeInterieur(new ArrayList<Float>());

			ascensseurModel.setEtageDestination(-1);

			ascensseurModel.resultatDirection = "";

			ascensseurModel.directionAsc = Constantes.HAUT;
			ascensseurModel.compeurTentativedirection = 0;
			remettreAllBouttonEteint();
		}

		// Lors de l'annulation de l'état d'urgence remètre à l'étage au dessous
		if (arg1 != null && (Boolean) arg1) {
			Float et = new Float(("" + ascensseurModel.getEtageActuel()).substring(0, 1));
			ascensseurModel.setEtageActuel(et.floatValue());
		}

		// Repait du panel d'animation avec la nouvelle position
		panelAnimation.repaint();
	}

	/**
	 * updateListeEtageDemanderAffichage méthode pour la mise à jours de
	 * l'affichage text des demandes qui sont effectuées de l'interieur de la
	 * cabine
	 */
	public void updateListeEtageDemanderAffichage() {
		List<Float> liste = this.ascensseurModel.getDemandeEtageDeInterieur();
		String str = "";
		for (int i = 0; i < liste.size(); i++) {
			str += liste.get(i).intValue() + " | ";
		}
		this.listeEtageInterieurDemandetextField.setText(str);
	}

	/**
	 * updateListeEtageDemandeMonteEtDescente méthode pour mise à jours de
	 * l'affichage text des demandes qui sont effectuées de l'exterieur de la
	 * cabine
	 */
	public void updateListeEtageDemandeMonteEtDescente() {
		List<Demande> listeDemandeExterieur = this.ascensseurModel.getDemandeEtageDeExterieur();

		String str1 = "";
		for (int i = 0; i < listeDemandeExterieur.size(); i++) {
			if (listeDemandeExterieur.get(i).getDirection().equals(Constantes.HAUT)) {
				str1 += ("" + listeDemandeExterieur.get(i).getEtage()).substring(0, 1) + " | ";
			}
		}
		this.listeDemandesExterieurMonte.setText(str1);

		String str2 = "";
		for (int i = 0; i < listeDemandeExterieur.size(); i++) {
			if (listeDemandeExterieur.get(i).getDirection().equals(Constantes.BAS)) {
				str2 += ("" + listeDemandeExterieur.get(i).getEtage()).substring(0, 1) + " | ";
			}
		}
		this.listeDemandesExterieurDescente.setText(str2);
	}

	/**
	 * updateEtageCourantAffichage méthode pour la mise à jours de l'affichage
	 * text et graphique de l'etage actuel de la cabine
	 */
	public void updateEtageCourantAffichage() {
		this.panelAnimation.y = new Float(430) - (this.ascensseurModel.getEtageActuel() * 80);
		this.etageActuelTextFild.setText(this.ascensseurModel.getEtageActuel() + "");

	}

	/**
	 * updateEtageDestinationAffichage pour la mise à jours de l'affichage text
	 * de la prochaine destination de la cabine
	 */
	public void updateEtageDestinationAffichage() {
		this.nextDestinationTextField.setText("" + this.ascensseurModel.getEtageDestination().intValue());
		if (this.ascensseurModel.getEtageDestination() == -1) {
			this.nextDestinationTextField.setText("...");
		}
	}

	/**
	 * addDemandeInterieur ajoute les demandes qui viennent de l'interieur de la
	 * cabine
	 * 
	 * @param etage
	 */
	public void addDemandeInterieur(float etage) {
		this.ascensseurModel.ajouterDemandeEtageInterieur(etage);
	}

	/**
	 * arretUrgence
	 */
	private void arretUrgence() {
		this.ascensseurModel.arretUrgence();
	}

	/**
	 * stopArretUrgence
	 */
	public void stopArretUrgence() {
		this.ascensseurModel.annulerArretUrgence();
	}

	public void setIconBouton(JButton bouton, Icon icon) {
		bouton.setIcon(icon);
	}

	/**
	 * addDemandeExterieur ajoute les demandes des utilisateurs qui sont à
	 * l'éxterieur de la cabine
	 * 
	 * @param etage
	 */
	public void addDemandeExterieur(float etage, String typeDemande) {
		this.ascensseurModel.ajouterDemandeExterieur(etage, typeDemande);
	}

	/**
	 * drowFenetre Création du visuel
	 */
	private void drowFenetre() {

		jFrame = new JFrame();
		jFrame.setSize(1140, 600);
		jFrame.setBackground(Color.WHITE);
		jFrame.setTitle("Simulation Ascenseur");
		Image icone = Toolkit.getDefaultToolkit()
				.getImage(getClass().getResource("/images/logo ladies&&gentlemen.png"));
		jFrame.setIconImage(icone);
		Toolkit tk = Toolkit.getDefaultToolkit();
		Dimension d = tk.getScreenSize();
		this.hEcran = (int) (d.getHeight());
		this.lEcran = (int) (d.getWidth());
		jFrame.setLocation((lEcran - jFrame.getWidth()) / 2, (hEcran - jFrame.getHeight()) / 2);
		jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jFrame.getContentPane().setBackground(Color.white);
		jFrame.getContentPane().setLayout(new FlowLayout());

		// Initialisation de l'ecran d'affichage
		panelAffichage = new JPanel();
		panelAffichage.setBackground(Color.WHITE);
		panelAffichage.setBorder(BorderFactory.createTitledBorder("Affichage simulation"));
		panelAffichage.setPreferredSize(new Dimension(400, 550));
		panelAffichage.setLayout(new FlowLayout());

		Font affichageEtage = new Font("SansSerif", Font.BOLD, 30);

		JPanel panVide1 = new JPanel();
		panVide1.setBackground(Color.WHITE);
		panVide1.setPreferredSize(new Dimension(350, 10));

		JPanel panVide2 = new JPanel();
		panVide2.setBackground(Color.WHITE);
		panVide2.setPreferredSize(new Dimension(350, 10));

		JPanel panVide3 = new JPanel();
		panVide3.setBackground(Color.WHITE);
		panVide3.setPreferredSize(new Dimension(350, 10));

		JPanel panVide4 = new JPanel();
		panVide4.setBackground(Color.WHITE);
		panVide4.setPreferredSize(new Dimension(350, 10));

		JPanel panVide5 = new JPanel();
		panVide5.setBackground(Color.WHITE);
		panVide5.setPreferredSize(new Dimension(350, 10));

		JPanel panVide6 = new JPanel();
		panVide6.setBackground(Color.WHITE);
		panVide6.setPreferredSize(new Dimension(350, 20));

		etageActuelTextFild = new JTextField();
		etageActuelTextFild.setPreferredSize(new Dimension(80, 50));
		etageActuelTextFild.setBackground(Color.WHITE);
		etageActuelTextFild.setForeground(Color.BLACK);
		etageActuelTextFild.setFont(affichageEtage);
		etageActuelTextFild.setHorizontalAlignment(JTextField.CENTER);
		etageActuelTextFild.setColumns(12);
		etageActuelTextFild.setEditable(false);

		listeEtageInterieurDemandetextField = new JTextField();
		listeEtageInterieurDemandetextField.setPreferredSize(new Dimension(80, 50));
		listeEtageInterieurDemandetextField.setBackground(Color.BLACK);
		listeEtageInterieurDemandetextField.setForeground(new Color(253, 63, 146));
		listeEtageInterieurDemandetextField.setFont(affichageEtage);
		listeEtageInterieurDemandetextField.setHorizontalAlignment(JTextField.CENTER);
		listeEtageInterieurDemandetextField.setColumns(12);
		listeEtageInterieurDemandetextField.setEditable(false);

		listeDemandesExterieurDescente = new JTextField();
		listeDemandesExterieurDescente.setPreferredSize(new Dimension(80, 50));
		listeDemandesExterieurDescente.setBackground(Color.BLACK);
		listeDemandesExterieurDescente.setForeground(new Color(253, 63, 146));
		listeDemandesExterieurDescente.setFont(affichageEtage);
		listeDemandesExterieurDescente.setHorizontalAlignment(JTextField.CENTER);
		listeDemandesExterieurDescente.setColumns(12);
		listeDemandesExterieurDescente.setEditable(false);

		listeDemandesExterieurMonte = new JTextField();
		listeDemandesExterieurMonte.setPreferredSize(new Dimension(80, 50));
		listeDemandesExterieurMonte.setBackground(Color.BLACK);
		listeDemandesExterieurMonte.setForeground(new Color(253, 63, 146));
		listeDemandesExterieurMonte.setFont(affichageEtage);
		listeDemandesExterieurMonte.setHorizontalAlignment(JTextField.CENTER);
		listeDemandesExterieurMonte.setColumns(12);
		listeDemandesExterieurMonte.setEditable(false);

		nextDestinationTextField = new JTextField();
		nextDestinationTextField.setBackground(Color.WHITE);
		nextDestinationTextField.setForeground(Color.BLACK);
		nextDestinationTextField.setFont(affichageEtage);
		nextDestinationTextField.setHorizontalAlignment(JTextField.CENTER);
		nextDestinationTextField.setPreferredSize(new Dimension(80, 50));
		nextDestinationTextField.setColumns(12);
		nextDestinationTextField.setEditable(false);

		port = new JLabel();
		port.setText("Porte fermée   " + "   []");
		port.setFont(new Font("SansSerif", Font.BOLD, 20));

		panelAffichage.add(panVide1);
		panelAffichage.add(new JLabel("Etage actuel"));
		panelAffichage.add(etageActuelTextFild);

		panelAffichage.add(panVide2);
		panelAffichage.add(new JLabel("Etages demandés (Interieur de la cabine)"));
		panelAffichage.add(listeEtageInterieurDemandetextField);

		panelAffichage.add(panVide3);
		panelAffichage.add(new JLabel("Demande exterieur pour descendre"));
		panelAffichage.add(listeDemandesExterieurDescente);

		panelAffichage.add(panVide4);
		panelAffichage.add(new JLabel("Demande exterieur pour monter"));
		panelAffichage.add(listeDemandesExterieurMonte);

		panelAffichage.add(panVide5);
		panelAffichage.add(new JLabel("procchaine destination"));
		panelAffichage.add(nextDestinationTextField);

		panelAffichage.add(panVide6);
		panelAffichage.add(port);

		// Initialisation interieur de la cabine
		panelCommandesInterieur = new JPanel();
		panelCommandesInterieur.setBorder(BorderFactory.createTitledBorder("Commandes interieur"));
		panelCommandesInterieur.setPreferredSize(new Dimension(250, 445));
		panelCommandesInterieur.setBackground(new Color(206, 206, 206));

		file = classLoader.getResource("images/n0b.png");
		ImageIcon iconEtage0 = new ImageIcon(file);

		file = classLoader.getResource("images/n0.png");
		ImageIcon iconEtage0Pressed = new ImageIcon(file);

		file = classLoader.getResource("images/n1b.png");
		ImageIcon iconEtage1 = new ImageIcon(file);

		file = classLoader.getResource("images/n1.png");
		ImageIcon iconEtage1Pressed = new ImageIcon(file);

		file = classLoader.getResource("images/n2b.png");
		ImageIcon iconEtage2 = new ImageIcon(file);

		file = classLoader.getResource("images/n2.png");
		ImageIcon iconEtage2Pressed = new ImageIcon(file);

		file = classLoader.getResource("images/n3b.png");
		ImageIcon iconEtage3 = new ImageIcon(file);

		file = classLoader.getResource("images/n3.png");
		ImageIcon iconEtage3Pressed = new ImageIcon(file);

		file = classLoader.getResource("images/n4b.png");
		ImageIcon iconEtage4 = new ImageIcon(file);

		file = classLoader.getResource("images/n4.png");
		ImageIcon iconEtage4Pressed = new ImageIcon(file);

		file = classLoader.getResource("images/n5b.png");
		ImageIcon iconEtage5 = new ImageIcon(file);

		file = classLoader.getResource("images/n5.png");
		ImageIcon iconEtage5Pressed = new ImageIcon(file);

		file = classLoader.getResource("images/up.png");
		ImageIcon up = new ImageIcon(file);

		file = classLoader.getResource("images/upPressed.png");
		ImageIcon upPressed = new ImageIcon(file);

		file = classLoader.getResource("images/down.png");
		ImageIcon down = new ImageIcon(file);

		file = classLoader.getResource("images/downPressed.png");
		ImageIcon downPressed = new ImageIcon(file);

		file = classLoader.getResource("images/stop.png");
		ImageIcon iconArretUrgence = new ImageIcon(file);

		file = classLoader.getResource("images/stopPressed.png");
		ImageIcon iconArretUrgencePressed = new ImageIcon(file);

		file = classLoader.getResource("images/goNO.png");
		ImageIcon iconStopArretUrgenceEt = new ImageIcon(file);

		file = classLoader.getResource("images/go.png");
		ImageIcon iconStopArretUrgence = new ImageIcon(file);

		file = classLoader.getResource("images/stop.png");

		etage5 = new JButton();
		etage5.setIcon(iconEtage5);
		etage5.setPreferredSize(new Dimension(100, 100));
		etage5.setFocusPainted(true);
		etage5.setContentAreaFilled(false);
		etage5.setOpaque(false);
		etage5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				addDemandeInterieur(5);
				setIconBouton(etage5, iconEtage5Pressed);
			}
		});

		etage4 = new JButton();
		etage4.setIcon(iconEtage4);
		etage4.setPreferredSize(new Dimension(100, 100));
		etage4.setFocusPainted(true);
		etage4.setContentAreaFilled(false);
		etage4.setOpaque(false);
		etage4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				addDemandeInterieur(4);
				setIconBouton(etage4, iconEtage4Pressed);
			}

		});

		etage3 = new JButton();
		etage3.setIcon(iconEtage3);
		etage3.setPreferredSize(new Dimension(100, 100));
		etage3.setFocusPainted(true);
		etage3.setContentAreaFilled(false);
		etage3.setOpaque(false);
		etage3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				addDemandeInterieur(3);
				setIconBouton(etage3, iconEtage3Pressed);
			}
		});

		etage2 = new JButton();
		etage2.setIcon(iconEtage2);
		etage2.setPreferredSize(new Dimension(100, 100));
		etage2.setFocusPainted(true);
		etage2.setContentAreaFilled(false);
		etage2.setOpaque(false);
		etage2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				addDemandeInterieur(2);
				setIconBouton(etage2, iconEtage2Pressed);
			}
		});
		panelCommandesInterieur.add(etage2);

		etage1 = new JButton();
		etage1.setIcon(iconEtage1);
		etage1.setPreferredSize(new Dimension(100, 100));
		etage1.setFocusPainted(true);
		etage1.setContentAreaFilled(false);
		etage1.setOpaque(false);
		etage1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				addDemandeInterieur(1);
				setIconBouton(etage1, iconEtage1Pressed);
			}
		});

		etage0 = new JButton(iconEtage0);
		etage0.setPreferredSize(new Dimension(100, 100));
		etage0.setFocusPainted(true);
		etage0.setContentAreaFilled(false);
		etage0.setOpaque(false);
		etage0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				addDemandeInterieur(0);
				setIconBouton(etage0, iconEtage0Pressed);
			}
		});

		stopArretUrgence = new JButton();
		stopArretUrgence.setIcon(iconStopArretUrgenceEt);
		stopArretUrgence.setPreferredSize(new Dimension(60, 60));
		stopArretUrgence.setFocusPainted(true);
		stopArretUrgence.setContentAreaFilled(false);
		stopArretUrgence.setOpaque(false);
		stopArretUrgence.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (ascensseurModel.isArretUrgence()) {
					setIconBouton(stopArretUrgence, iconStopArretUrgenceEt);
					setIconBouton(arretUrgence, iconArretUrgence);
					stopArretUrgence();
				}

			}
		});

		arretUrgence = new JButton();
		arretUrgence.setIcon(iconArretUrgence);

		arretUrgence.setPreferredSize(new Dimension(100, 100));
		arretUrgence.setFocusPainted(true);
		arretUrgence.setContentAreaFilled(false);
		arretUrgence.setOpaque(false);
		arretUrgence.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				setIconBouton(arretUrgence, iconArretUrgencePressed);
				setIconBouton(stopArretUrgence, iconStopArretUrgence);
				arretUrgence();

			}
		});

		panelCommandesInterieur.add(etage4);
		panelCommandesInterieur.add(etage5);
		panelCommandesInterieur.add(etage2);
		panelCommandesInterieur.add(etage3);
		panelCommandesInterieur.add(etage0);
		panelCommandesInterieur.add(etage1);

		panelCommandesInterieur.add(arretUrgence);

		panelStopArretUrgenceCommandesInterieur = new JPanel();
		panelStopArretUrgenceCommandesInterieur.setPreferredSize(new Dimension(250, 550));
		panelStopArretUrgenceCommandesInterieur.setBackground(Color.WHITE);

		JPanel panelStopArretUrgnce = new JPanel();
		panelStopArretUrgnce.setBorder(BorderFactory.createTitledBorder("Stop arrêt urgence"));
		panelStopArretUrgnce.setPreferredSize(new Dimension(250, 95));
		panelStopArretUrgnce.setBackground(Color.WHITE);

		panelStopArretUrgnce.add(stopArretUrgence);

		panelCommandeExterne = new JPanel();
		panelCommandeExterne.setBorder(BorderFactory.createTitledBorder("Commandes Exterieur "));
		panelCommandeExterne.setPreferredSize(new Dimension(330, 540));
		panelCommandeExterne.setBackground(new Color(206, 206, 206));

		JLabel etage0 = new JLabel("RDC       ");
		JLabel etage1 = new JLabel("1er  Etage ");
		JLabel etage2 = new JLabel("2eme Etage");
		JLabel etage3 = new JLabel("3eme Etage");
		JLabel etage4 = new JLabel("4eme Etage");
		JLabel etage5 = new JLabel("5eme Etage                 ");
		JLabel vide0 = new JLabel("            ");
		JLabel vide1 = new JLabel("");
		JLabel vide2 = new JLabel(" ");

		boutonUpEtage0 = new JButton("");
		boutonUpEtage0.setIcon(up);
		boutonUpEtage0.setPreferredSize(new Dimension(70, 70));
		boutonUpEtage0.setFocusPainted(true);
		boutonUpEtage0.setContentAreaFilled(false);
		boutonUpEtage0.setOpaque(false);
		boutonUpEtage0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				boutonUpEtage0.setIcon(upPressed);
				addDemandeExterieur(0, Constantes.HAUT);
			}
		});

		boutonDownEtage1 = new JButton("");
		boutonDownEtage1.setIcon(down);
		boutonDownEtage1.setPreferredSize(new Dimension(70, 70));
		boutonDownEtage1.setFocusPainted(true);
		boutonDownEtage1.setContentAreaFilled(false);
		boutonDownEtage1.setOpaque(false);
		boutonDownEtage1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				boutonDownEtage1.setIcon(downPressed);
				addDemandeExterieur(1, Constantes.BAS);
			}
		});

		boutonUpEtage1 = new JButton("");
		boutonUpEtage1.setPreferredSize(new Dimension(70, 70));
		boutonUpEtage1.setIcon(up);
		boutonUpEtage1.setFocusPainted(true);
		boutonUpEtage1.setContentAreaFilled(false);
		boutonUpEtage1.setOpaque(false);
		boutonUpEtage1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				boutonUpEtage1.setIcon(upPressed);
				addDemandeExterieur(1, Constantes.HAUT);
			}
		});

		boutonDownEtage2 = new JButton("");
		boutonDownEtage2.setIcon(down);
		boutonDownEtage2.setPreferredSize(new Dimension(70, 70));
		boutonDownEtage2.setFocusPainted(true);
		boutonDownEtage2.setContentAreaFilled(false);
		boutonDownEtage2.setOpaque(false);
		boutonDownEtage2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				boutonDownEtage2.setIcon(downPressed);
				addDemandeExterieur(2, Constantes.BAS);
			}
		});

		boutonUpEtage2 = new JButton("");
		boutonUpEtage2.setIcon(up);
		boutonUpEtage2.setPreferredSize(new Dimension(70, 70));
		boutonUpEtage2.setFocusPainted(true);
		boutonUpEtage2.setContentAreaFilled(false);
		boutonUpEtage2.setOpaque(false);
		boutonUpEtage2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				boutonUpEtage2.setIcon(upPressed);
				addDemandeExterieur(2, Constantes.HAUT);
			}
		});

		boutonDownEtage3 = new JButton("");
		boutonDownEtage3.setIcon(down);
		boutonDownEtage3.setPreferredSize(new Dimension(70, 70));
		boutonDownEtage3.setFocusPainted(true);
		boutonDownEtage3.setContentAreaFilled(false);
		boutonDownEtage3.setOpaque(false);
		boutonDownEtage3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				boutonDownEtage3.setIcon(downPressed);
				addDemandeExterieur(3, Constantes.BAS);
			}
		});

		boutonUpEtage3 = new JButton("");
		boutonUpEtage3.setIcon(up);
		boutonUpEtage3.setPreferredSize(new Dimension(70, 70));
		boutonUpEtage3.setFocusPainted(true);
		boutonUpEtage3.setContentAreaFilled(false);
		boutonUpEtage3.setOpaque(false);
		boutonUpEtage3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				boutonUpEtage3.setIcon(upPressed);
				addDemandeExterieur(3, Constantes.HAUT);
			}
		});

		boutonDownEtage4 = new JButton("");
		boutonDownEtage4.setIcon(down);
		boutonDownEtage4.setPreferredSize(new Dimension(70, 70));
		boutonDownEtage4.setFocusPainted(true);
		boutonDownEtage4.setContentAreaFilled(false);
		boutonDownEtage4.setOpaque(false);
		boutonDownEtage4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				boutonDownEtage4.setIcon(downPressed);
				addDemandeExterieur(4, Constantes.BAS);
			}
		});

		boutonUpEtage4 = new JButton("");
		boutonUpEtage4.setIcon(up);
		boutonUpEtage4.setPreferredSize(new Dimension(70, 70));
		boutonUpEtage4.setFocusPainted(true);
		boutonUpEtage4.setContentAreaFilled(false);
		boutonUpEtage4.setOpaque(false);
		boutonUpEtage4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				boutonUpEtage4.setIcon(upPressed);
				addDemandeExterieur(4, Constantes.HAUT);
			}
		});

		boutonDownEtage5 = new JButton("");
		boutonDownEtage5.setIcon(down);
		boutonDownEtage5.setPreferredSize(new Dimension(70, 70));
		boutonDownEtage5.setFocusPainted(true);
		boutonDownEtage5.setContentAreaFilled(false);
		boutonDownEtage5.setOpaque(false);
		boutonDownEtage5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				boutonDownEtage5.setIcon(downPressed);
				addDemandeExterieur(5, Constantes.BAS);
			}
		});

		JSeparator jSeparator1 = new JSeparator();
		jSeparator1.setBorder(new LineBorder(new Color(0, 0, 0)));
		jSeparator1.setPreferredSize(new java.awt.Dimension(250, 2));

		JSeparator jSeparator2 = new JSeparator();
		jSeparator2.setBorder(new LineBorder(new Color(0, 0, 0)));
		jSeparator2.setPreferredSize(new java.awt.Dimension(250, 2));

		JSeparator jSeparator3 = new JSeparator();
		jSeparator3.setBorder(new LineBorder(new Color(0, 0, 0)));
		jSeparator3.setPreferredSize(new java.awt.Dimension(250, 2));

		JSeparator jSeparator4 = new JSeparator();
		jSeparator4.setBorder(new LineBorder(new Color(0, 0, 0)));
		jSeparator4.setPreferredSize(new java.awt.Dimension(250, 2));

		JSeparator jSeparator5 = new JSeparator();
		jSeparator5.setBorder(new LineBorder(new Color(0, 0, 0)));
		jSeparator5.setPreferredSize(new java.awt.Dimension(250, 2));

		panelCommandeExterne.add(etage5);
		panelCommandeExterne.add(vide2);
		panelCommandeExterne.add(boutonDownEtage5);
		panelCommandeExterne.add(jSeparator5);

		panelCommandeExterne.add(etage4);
		panelCommandeExterne.add(boutonUpEtage4);
		panelCommandeExterne.add(boutonDownEtage4);

		panelCommandeExterne.add(jSeparator3);
		panelCommandeExterne.add(etage3);
		panelCommandeExterne.add(boutonUpEtage3);
		panelCommandeExterne.add(boutonDownEtage3);

		panelCommandeExterne.add(jSeparator2);
		panelCommandeExterne.add(etage2);
		panelCommandeExterne.add(boutonUpEtage2);
		panelCommandeExterne.add(boutonDownEtage2);

		panelCommandeExterne.add(jSeparator1);
		panelCommandeExterne.add(etage1);
		panelCommandeExterne.add(boutonUpEtage1);
		panelCommandeExterne.add(boutonDownEtage1);

		panelCommandeExterne.add(jSeparator4);
		panelCommandeExterne.add(vide1);
		panelCommandeExterne.add(etage0);
		panelCommandeExterne.add(boutonUpEtage0);
		panelCommandeExterne.add(vide0);

		panelAnimation = new panelAnimation();

		panelStopArretUrgenceCommandesInterieur.add(panelCommandesInterieur);
		panelStopArretUrgenceCommandesInterieur.add(panelStopArretUrgnce);

		jFrame.getContentPane().add(panelAffichage);
		jFrame.getContentPane().add(panelStopArretUrgenceCommandesInterieur);
		jFrame.getContentPane().add(panelAnimation);
		jFrame.getContentPane().add(panelCommandeExterne);

		jFrame.setVisible(true);
	}

	public void remettreBouttonEteint() {
		if (ascensseurModel.getEtageActuel() == ascensseurModel.getEtageDestination()) {
			float b = this.ascensseurModel.getEtageDestination();
			switch (new Float(b).intValue()) {
			case 0:
				file = classLoader.getResource("images/n0b.png");
				ImageIcon etage0_et = new ImageIcon(file);
				setIconBouton(etage0, etage0_et);
				break;

			case 1:
				file = classLoader.getResource("images/n1b.png");
				ImageIcon etage1_et = new ImageIcon(file);
				setIconBouton(etage1, etage1_et);
				break;
			case 2:
				file = classLoader.getResource("images/n2b.png");
				ImageIcon etage2_et = new ImageIcon(file);
				setIconBouton(etage2, etage2_et);
				break;
			case 3:
				file = classLoader.getResource("images/n3b.png");
				ImageIcon etage3_et = new ImageIcon(file);
				setIconBouton(etage3, etage3_et);
				break;
			case 4:
				file = classLoader.getResource("images/n4b.png");
				ImageIcon etage4_et = new ImageIcon(file);
				setIconBouton(etage4, etage4_et);
				break;
			case 5:
				file = classLoader.getResource("images/n5b.png");
				ImageIcon etage5_et = new ImageIcon(file);
				setIconBouton(etage5, etage5_et);
				break;

			default:
				break;
			}
		}
	}

	/**
	 * Méthode remettreAllBouttonEteint
	 */
	public void remettreAllBouttonEteint() {

		// Bouton interieur de la cabine
		file = classLoader.getResource("images/n0b.png");
		ImageIcon etage0_et = new ImageIcon(file);
		setIconBouton(etage0, etage0_et);

		file = classLoader.getResource("images/n1b.png");
		ImageIcon etage1_et = new ImageIcon(file);
		setIconBouton(etage1, etage1_et);

		file = classLoader.getResource("images/n2b.png");
		ImageIcon etage2_et = new ImageIcon(file);
		setIconBouton(etage2, etage2_et);

		file = classLoader.getResource("images/n3b.png");
		ImageIcon etage3_et = new ImageIcon(file);
		setIconBouton(etage3, etage3_et);

		file = classLoader.getResource("images/n4b.png");
		ImageIcon etage4_et = new ImageIcon(file);
		setIconBouton(etage4, etage4_et);

		file = classLoader.getResource("images/n5b.png");
		ImageIcon etage5_et = new ImageIcon(file);
		setIconBouton(etage5, etage5_et);

		// Bouton éxterier de la cabine
		file = classLoader.getResource("images/up.png");
		ImageIcon up_et = new ImageIcon(file);

		setIconBouton(boutonUpEtage0, up_et);
		setIconBouton(boutonUpEtage1, up_et);
		setIconBouton(boutonUpEtage2, up_et);
		setIconBouton(boutonUpEtage3, up_et);
		setIconBouton(boutonUpEtage4, up_et);

		file = classLoader.getResource("images/down.png");
		ImageIcon down_et = new ImageIcon(file);

		setIconBouton(boutonDownEtage1, down_et);
		setIconBouton(boutonDownEtage2, down_et);
		setIconBouton(boutonDownEtage3, down_et);
		setIconBouton(boutonDownEtage4, down_et);
		setIconBouton(boutonDownEtage5, down_et);
	}

	public void ouvrirPort() {
		port.setText("Porte ouverte   " + "   [      ]");
	}

	public void fermerPort() {
		port.setText("Porte fermée   " + "   []");
	}

}
