package run;

import Controleur.Controleur;

/**
 * 
 * Class Lancer qui contient le main pour le lancement du 
 * programme
 *
 */

public class Lancer {

	private static Controleur controleur;

	public static void main(String[] args) {
		
		// Création d'un contreleur
		controleur = new Controleur();
		// Lancement du programme
		controleur.go();
	}
}
